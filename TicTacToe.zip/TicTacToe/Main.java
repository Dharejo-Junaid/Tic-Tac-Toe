import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;

import java.awt.Color;
import java.awt.Font;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.Dimension;
import java.awt.Cursor;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.FocusListener;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import java.util.Random;

class TicTacToe implements ActionListener {

    JFrame frame;
    JPanel panel;
    JButton[] button;
    
    JPanel topPanel;
    JLabel label;
    JButton resetButton;
    JButton scoreButton;
    
    Font mvBoli;
    Font inkFree;

    boolean xTurn=false, isWinned=false;
    Random rd = new Random();
    int counter=0;
    
    int winCondition[][]={ {0, 1, 2}, {3, 4, 5}, {6, 7, 8},
        {0, 3, 6}, {1, 4, 7,}, {2, 5, 8}, {0, 4, 8}, {2, 4, 6} };
    int selected[]=new int[9];

    TicTacToe() {
        
        mvBoli = new Font("Mv Boli", Font.ITALIC, 40);
        inkFree = new Font("Ink Free", Font.BOLD, 25);

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 550);
        frame.setLocationRelativeTo(null);
        frame.setLayout(new BorderLayout(10, 10));
        frame.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                int i=e.getKeyChar()-'1';
                if(i>=0 && i<=8) play(i);
            }
        });

        topPanel = new JPanel();
        topPanel.setLayout(new BorderLayout());

        label = new JLabel();
        label.setText("Start Game");
        label.setPreferredSize(new Dimension(frame.getWidth(), 70));
        label.setFont(mvBoli);
        label.setBackground(Color.BLACK);
        label.setOpaque(true);
        label.setForeground(Color.WHITE);
        label.setHorizontalAlignment(JLabel.CENTER);

        resetButton = new JButton("RESET");
        resetButton.setPreferredSize(new Dimension(130, 50));
        resetButton.setFont(inkFree);
        resetButton.setFocusable(false);
        resetButton.addActionListener(e -> {
            frame.dispose();
            new TicTacToe();
        });

        scoreButton = new JButton("Score");
        scoreButton.setPreferredSize(new Dimension(130, 50));
        scoreButton.setFont(inkFree);
        scoreButton.setFocusable(false);
        scoreButton.addActionListener(e -> {
            new ShowResult();
        });

        panel = new JPanel();
        panel.setLayout(new GridLayout(3, 3, 10, 10));

        button = new JButton[9];
        for(int i=0; i<9; i++) {
            button[i] = new JButton();
            button[i].setFocusable(false);
            button[i].setFont(new Font("Mv Boli", Font.BOLD, 50));
            button[i].addActionListener(this);
            button[i].setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            panel.add(button[i]);
        }

        topPanel.add(label, BorderLayout.CENTER);
        topPanel.add(resetButton, BorderLayout.WEST);
        topPanel.add(scoreButton, BorderLayout.EAST);

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(panel, BorderLayout.CENTER);
        frame.setVisible(true);

        // set turn (X || O);
        xTurn = rd.nextBoolean();
        label.setText(xTurn? Start.name1+"'s Turn" : Start.name2+"'s Turn");
    }

    public void changeColor(int... idx) {
        
        button[idx[0]].setBackground(Color.GREEN);
        button[idx[1]].setBackground(Color.GREEN);
        button[idx[2]].setBackground(Color.GREEN);
    }

    public boolean checkWin() {
        
        counter++;

        for(int i=0; i<winCondition.length; i++) {
            if(selected[winCondition[i][0]]==selected[winCondition[i][1]]
                && selected[winCondition[i][1]]==selected[winCondition[i][2]]
                    && selected[winCondition[i][0]]!=0){
                changeColor(winCondition[i]);
                isWinned=true;
                return true;
            }
        }

        if(counter==9) {
            Start.tieNumber++;
            label.setText("Game is tie");
        }

        return false;
    }

    public boolean isSelected(int i) {
        return (selected[i]==1 || selected[i]==2);
    }

    public void play(int i) {
        if(isSelected(i) || isWinned) {
            return;
        }

        else if(xTurn) {
            label.setText(Start.name2+"'s Turn");
            xTurn=false;

            selected[i]=1;
            button[i].setText("X");

            if(checkWin()){
                Start.score1++;
                label.setText(Start.name1+" Wins");
                return;
            }

            return;
        }

        else {
            label.setText(Start.name1+"'s Turn");
            xTurn=true;

            selected[i]=2;
            button[i].setText("O");

            if(checkWin()){
                Start.score2++;
                label.setText(Start.name2+" Wins");
                return;
            }

            return;
        }
    }

    // @Override
    public void actionPerformed(ActionEvent e) {
        for(int i=0; i<9; i++) {
            if(e.getSource()==button[i]) {
                play(i);
            }
        }
    }

}

class PTextField extends JTextField {

    private String promptText;

    PTextField() {
        this.addFocusListener(new FocusListener() {

            public void focusGained(FocusEvent e) {
                if(getText().trim().equals(promptText)) {
                    setText("");
                }
            }

            public void focusLost(FocusEvent e) {
                if(getText().trim().isEmpty()) {
                    setText(promptText);
                }
            }
        });
    }

    public void setPromptText(String text) {
        this.promptText=text.trim();
    }

    public String getPromptText() {
        return this.promptText;
    }

    public boolean isTextFieldEmpty() {
        return (this.getText().trim().isEmpty() || 
            this.getText().trim().equals(this.getPromptText()));
    }
}

class Start {

    JFrame frame;
    JLabel label;
    PTextField player1;
    PTextField player2;
    JButton start;

    Font timesNewRoman;

    static String name1="", name2="";
    static int score1=0, score2=0, tieNumber=0;

    Start() {

        timesNewRoman = new Font("Times new Roman", Font.PLAIN, 20);

        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.setLocationRelativeTo(null);
        frame.setBackground(Color.BLACK);

        label = new JLabel();
        label.setText("Welcome to Tic-Tac-Toe");
        label.setFont(new Font("Times new Roman", Font.ITALIC, 30));
        label.setBounds(0, 0, 400, 60);
        label.setBackground(Color.WHITE);
        label.setOpaque(true);
        label.setHorizontalAlignment(JLabel.CENTER);

        player1 = new PTextField();
        player1.setFont(timesNewRoman);
        player1.setPromptText("Enter Player one");
        player1.setBounds(80, 80, 230, 50);
        player1.addActionListener(e  -> {
            actionPerformed();
        });

        player2 = new PTextField();
        player2.setFont(timesNewRoman);
        player2.setPromptText("Enter Player two");
        player2.setBounds(80, 180, 230, 50);
        player2.addActionListener(e  -> {
            actionPerformed();
        });

        start = new JButton("start");
        start.setBounds(130, 280, 140, 50);
        start.setFocusable(false);
        start.setFont(new Font("Verdana", Font.ITALIC, 25));
        start.addActionListener(e  -> {
            actionPerformed();
        });

        frame.add(label);
        frame.add(player1);
        frame.add(player2);
        frame.add(start);
        frame.setVisible(true);
    }

    // actionPerformed

    public void actionPerformed() {
        if(!player1.isTextFieldEmpty() && !player2.isTextFieldEmpty()) {
            name1=player1.getText();
            name2=player2.getText();

            frame.dispose();
            new TicTacToe();
        }
    }
}

class ShowResult {
    JFrame frame;
    JLabel label1, label2, label3, label4;

    Font mvBoli;

    ShowResult() {

        mvBoli = new Font("Mv Boli", Font.ITALIC, 45);

        frame = new JFrame();
        frame.setSize(400, 400);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setResizable(false);
        frame.setLayout(null);
        frame.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                frame.dispose();
            }
        });

        frame.addKeyListener(new KeyAdapter() {
            public void keyTyped(KeyEvent e) {
                frame.dispose();
            }
        });

        label1 = new JLabel();
        label1.setText("Result");
        label1.setBounds(0, 0, 400, 70);
        label1.setFont(mvBoli);
        label1.setHorizontalAlignment(JLabel.CENTER);
        label1.setBackground(Color.BLACK);
        label1.setForeground(Color.WHITE);
        label1.setOpaque(true);

        label2 = new JLabel();
        label2.setText(Start.name1 + " = " + Start.score1);
        label2.setBounds(0, 70, 400, 100);
        label2.setFont(mvBoli);
        label2.setHorizontalAlignment(JLabel.CENTER);
        
        label3 = new JLabel();
        label3.setText(Start.name2 + " = " + Start.score2);
        label3.setBounds(0, 170, 400, 100);
        label3.setFont(mvBoli);
        label3.setHorizontalAlignment(JLabel.CENTER);
        
        label4 = new JLabel();
        label4.setText("Tie Games = " + Start.tieNumber);
        label4.setBounds(0, 270, 400, 100);
        label4.setFont(mvBoli);
        label4.setHorizontalAlignment(JLabel.CENTER);
        

        frame.add(label1);
        frame.add(label2);
        frame.add(label3);
        frame.add(label4);
        frame.setVisible(true);
    }
}

public class Main {
    public static void main(String args []) {
        Start st=new Start();
        // TicTacToe ttt=new TicTacToe();
        // ShowResult r=new ShowResult();
    }
}